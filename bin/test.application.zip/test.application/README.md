# kuali-coeus-test-app
Test application to show maven overlaying in work

**Prerequisites**
Maven 3.3.x Java 1.8.x Tomcat 7.x MySQL 5.6.x Git 2.4.x

**HowTo build:**
 1. install Oracle JDK 1.8.x
 2. build https://github.com/kuali/kc project using Oracle JDK
 3. build current project via mvn clean install
