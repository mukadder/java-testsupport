package org.kuali.coeus.award.finance;


public enum AccountStatus {
    AVAILABLE, CLOSED
}
